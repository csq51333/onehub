# snakeGame
这是一个使用原生JavaScript+js面向对象思想实现的一个简单的贪吃蛇小游戏！
# 贪吃蛇小游戏体验地址
[立即体验](https://941477276.github.io/snakeGame/)